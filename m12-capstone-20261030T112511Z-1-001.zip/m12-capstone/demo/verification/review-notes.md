# Review Notes: Capstone AI Responses

## Scope

Reviewed the troubleshooting analysis and blameless RCA in `demo/responses/verification/` against the supplied router output and incident timeline in `samples/`. The source files are fictional training evidence. No credentials or personal identifiers are reproduced here.

## Findings and Evidence Match

- **BGP troubleshooting response:** The evidence shows the neighbor Up at 09:05:46.120 and a later hold-time expiry at 09:08:49.637, a difference of about 3 minutes 3.5 seconds. The 1500-size DF-bit ping failed all five attempts and the 1400-size ping succeeded all five. The ISP migration is recorded before these events. The response reports these facts accurately and labels the MTU/large-packet explanation probable rather than confirmed.
- **Blameless RCA:** The timeline supports the 00:07:43 hold-time expiry, neighbor Down, and IPv4 Unicast topology removal; the neighbor returned Up at 00:39:52 and monitoring reported Established at 00:39:58. The Down-to-Up interval is about 32 minutes 9 seconds. The response accurately distinguishes the observed adjacency duration from unknown customer impact.
- The RCA also treats the 00:04:41 configuration event as a lead rather than proof of cause, leaves the 00:05 bridge phrase ambiguous, and describes the missing bridge entries before 00:28 as an evidence gap. These are appropriately bounded by the supplied timeline.

## Unsupported Assumptions

- Neither response asserts a confirmed initiating root cause. The troubleshooting response's path-MTU hypothesis is plausible from the packet-size difference, but the evidence does not show that BGP packets were dropped for the same reason. ICMP filtering/rate limiting and other causes remain possible, as the response notes.
- The supplied troubleshooting evidence contains one Up followed by one later hold-time expiry. It cannot establish a recurring pattern after "every Up" or prove the general MTU heuristic in the prompt. The response does not claim that broader pattern as a finding, but its wording should be read as a hypothesis, not proof.
- The ISP migration is temporally prior, but no evidence links it causally to the flap. The response handles this limitation correctly.
- Checking peer-side counters, path interfaces, or ISP records assumes those records and access are available. These are investigation suggestions, not claims that such access or telemetry exists; availability should be confirmed.

## Read-Only Assessment

- BGP detail/counter queries, interface MTU and counter inspection, and review of logs, telemetry, and change records are read-only when done as observational checks. The RCA follow-up actions are also framed as record/telemetry reviews, not configuration changes.
- Repeating DF-bit pings is **not strictly read-only**: it sends active probe traffic across the network. The probe does not change configuration, but should be authorized and run only when its operational impact is acceptable.
- No configuration changes are recommended in either response.

## Corrections Made

- Updated the troubleshooting response heading from “Recommended read-only verification” to “Recommended verification” and added a note that observational checks are read-only while repeated DF-bit pings are active probes. This avoids classifying every proposed test as read-only.
- No changes were made to the RCA response. Its evidence limits and its refusal to invent a cause or due dates are appropriate.

## Prompt-Format Note

The RCA prompt requested a branched 5 Whys, a factor table with a Category column, and action fields including Type and Due. The response provides a linear evidence-limited Why chain and omits those requested table fields. This is a format-compliance gap, not an evidentiary error. Avoiding unsupported categories or due dates is preferable to fabricating them; a revised prompt or output schema should allow “undetermined” or “not supplied” where evidence is missing.
