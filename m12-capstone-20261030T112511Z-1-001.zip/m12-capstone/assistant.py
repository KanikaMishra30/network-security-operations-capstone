#!/usr/bin/env python3
"""assistant.py - capstone starter for the AI-Powered Network & Security Operations Assistant.

Provides the three mandatory-core building blocks; teams wire in their own prompts,
earlier lab scripts and two optional modules.

  troubleshoot  sanitise evidence, fill a runbook prompt, save it (and optionally send it)
  rca           build a blameless RCA prompt from an incident timeline
  action        human approval gate for any operation, with tiers and an audit trail
  check         scan a file for secrets or personal data before it goes into a prompt
    logs          run read-only entity-filtered log correlation

The assistant never sends data anywhere by default: prompts are written to out/ for
pasting into the approved AI tool. To call your approved LLM directly, implement
llm_call() - every prompt still passes through sanitise() and check() first.

Examples:
  python3 assistant.py check samples/router-output.txt
  python3 assistant.py troubleshoot --symptom bgp --evidence samples/router-output.txt
  python3 assistant.py rca --timeline samples/timeline.txt --incident INC-OUTAGE-1015
    python3 assistant.py logs --entity r.mehta --entity 10.20.250.37
  python3 assistant.py action --name "open ticket for INC-OUTAGE-1015" --tier T1
  python3 assistant.py action --name "block_ip 198.51.100.77" --tier T2
"""
import argparse
import getpass
import json
import re
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).parent
OUT = BASE / "out"
AUDIT = BASE / "audit" / "assistant-audit.jsonl"
LOG_HELPER = BASE.parent / "m06-threat-analysis" / "correlate.py"
LOG_DIR = LOG_HELPER.parent / "logs"
LOG_FILES = (
    "fw-pun-01-vpn.log",
    "fw-pun-01-traffic.log",
    "nps-auth.csv",
    "proxy-access.log",
    "srv-file01-auth.log",
    "srv-db01-auth.log",
)

# Module 10 sanitising rules, extended. Order matters: secrets first.
RULES = [
    (r"(?s)-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----.*?-----END [A-Z0-9 ]*PRIVATE KEY-----", "<REDACTED-PRIVATE-KEY>"),
    (r"(?i)\b(password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|client[_-]?secret|private[_-]?key)\b(?:[ \t]*[:=][ \t]*|\s+(?:\d+\s+)?)(?:\"[^\"]*\"|'[^']*'|[^\s,;#]+)", r"\1<REDACTED>"),
    (r"(?i)\b(authorization[ \t]*:[ \t]*(?:bearer|basic)|bearer)[ \t]+\S+", r"\1 <REDACTED>"),
    (r"(?i)(https?://)[^/\s:@]+:[^/\s@]+@", r"\1<REDACTED>@"),
    (r"(snmp-server community )\S+", r"\1<REDACTED>"),
    (r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", "<EMAIL>"),
    (r"\+91-?[0-9x]{10}", "<PHONE>"),
    (r"(Configured from console by )\S+", r"\1<USER>"),          # blameless RCA: no names
    (r"([\w-]+) \([a-z][\w.]*\):", r"\1 (<PERSON>):"),          # chat lines "Role (name):"
]
CHECKS = {
    "credential assignment": r"(?i)\b(password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|client[_-]?secret|private[_-]?key)\b(?:[ \t]*[:=][ \t]*|\s+(?:\d+\s+)?)(?!<REDACTED>)(?:\"[^\"]*\"|'[^']*'|[^\s,;#]+)",
    "authorization credential": r"(?i)\b(?:authorization[ \t]*:[ \t]*(?:bearer|basic)|bearer)[ \t]+(?!<REDACTED>)\S+",
    "URL credential": r"(?i)https?://[^/\s:@]+:[^/\s@]+@",
    "SNMP community": r"(?i)snmp-server community[ \t]+(?!<REDACTED>)\S+",
    "email address": r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",
    "private key": r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----",
    "instruction-like text": r"ignore (all )?(previous|prior) instructions",
}
TIERS = {"T0": "read-only, runs", "T1": "low-risk write, needs approval",
         "T2": "change, proposal only - a human executes", "T3": "never allowed"}


def audit(event, **kw):
    AUDIT.parent.mkdir(exist_ok=True)
    rec = {"ts": datetime.now().isoformat(timespec="seconds"), "event": event, **kw}
    with AUDIT.open("a") as f:
        f.write(json.dumps(rec) + "\n")


def sanitise(text):
    for pat, rep in RULES:
        text = re.sub(pat, rep, text)
    return text


def check(text):
    """Return finding categories only; matched content may contain sensitive data."""
    return [name for name, pat in CHECKS.items() for _ in re.finditer(pat, text, re.I)]


def fill(template_name, **values):
    tpl = (BASE / "prompts" / template_name).read_text()
    for k, v in values.items():
        tpl = tpl.replace("{{" + k + "}}", v)
    missing = re.findall(r"\{\{(\w+)\}\}", tpl)
    if missing:
        raise SystemExit(f"Template still has placeholders: {missing}")
    return tpl


def save_prompt(name, prompt):
    OUT.mkdir(exist_ok=True)
    path = OUT / f"{name}-{datetime.now():%Y%m%d-%H%M%S}.txt"
    path.write_text(prompt)
    return path


def llm_call(prompt):
    # In this course the AI is GitHub Copilot Chat: open the prompt file saved in out/
    # and send it to Copilot with #file. Nothing here calls an AI service.
    raise NotImplementedError("Open the prompt in out/ and send it to GitHub Copilot Chat with #file.")


def cmd_check(a):
    findings = check(Path(a.file).read_text())
    for name in findings:
        print(f"FOUND  {name}")
    print("CLEAN" if not findings else f"{len(findings)} finding(s): fix before using this file in a prompt")
    audit("check", file=a.file, findings=len(findings))


def cmd_troubleshoot(a):
    evidence = sanitise(Path(a.evidence).read_text())
    issues = check(evidence)
    if issues:
        raise SystemExit(f"Stopped: sanitised evidence still contains {issues}")
    prompt = fill(f"runbook-{a.symptom}.md", evidence=evidence)
    path = save_prompt(f"troubleshoot-{a.symptom}", prompt)
    audit("troubleshoot", symptom=a.symptom, evidence=a.evidence, prompt=str(path.relative_to(BASE)))
    print(f"Prompt ready (sanitised): {path.relative_to(BASE)}")
    if a.send:
        print(llm_call(prompt))


def cmd_rca(a):
    timeline = sanitise(Path(a.timeline).read_text())
    issues = check(timeline)
    if issues:
        raise SystemExit(f"Stopped: timeline still contains {issues}")
    prompt = fill("rca.md", incident=a.incident, timeline=timeline)
    path = save_prompt(f"rca-{a.incident}", prompt)
    audit("rca", incident=a.incident, prompt=str(path.relative_to(BASE)))
    print(f"RCA prompt ready: {path.relative_to(BASE)}")


def cmd_logs(a):
    entities = [sanitise(entity.strip()) for entity in a.entity]
    audit_entities = entities
    decision = "stopped"
    prompt_path = None
    findings = []
    try:
        if not entities or any(not entity for entity in entities):
            raise SystemExit("Stopped: at least one non-empty entity is required.")
        for entity in entities:
            findings = check(entity)
            if findings:
                audit_entities = ["<REDACTED>"]
                raise SystemExit(f"Stopped: sanitised entity still contains {findings}")

        with tempfile.TemporaryDirectory(prefix="capstone-logs-") as temp_dir:
            temp_logs = Path(temp_dir)
            for name in LOG_FILES:
                evidence = sanitise((LOG_DIR / name).read_text())
                findings = check(evidence)
                if findings:
                    raise SystemExit(f"Stopped: sanitised input evidence still contains {findings}")
                (temp_logs / name).write_text(evidence)

            result = subprocess.run(
                [
                    sys.executable,
                    str(LOG_HELPER),
                    "--logs",
                    str(temp_logs),
                    *[f"--entity={entity}" for entity in entities],
                ],
                cwd=LOG_HELPER.parent,
                capture_output=True,
                text=True,
                check=False,
            )
            helper_output = sanitise(result.stdout)
            helper_error = sanitise(result.stderr)
            findings = check(f"{helper_output}\n{helper_error}")
            if findings:
                raise SystemExit(f"Stopped: sanitised helper output still contains {findings}")
            if result.returncode:
                raise SystemExit("Stopped: log correlation helper failed.")
            if not helper_output.strip():
                raise SystemExit("Stopped: helper returned no matching evidence.")

        prompt = sanitise(fill("logs.md", evidence=helper_output))
        findings = check(prompt)
        if findings:
            raise SystemExit(f"Stopped: generated prompt still contains {findings}")
        prompt_path = save_prompt("logs", prompt)
        decision = "saved"
        print(f"Log prompt ready (sanitised): {prompt_path.relative_to(BASE)}")
    finally:
        audit(
            "logs",
            entity=audit_entities,
            decision=decision,
            findings=len(findings),
            prompt=str(prompt_path.relative_to(BASE)) if prompt_path else None,
        )


def cmd_action(a):
    tier = a.tier
    print(f"Action: {a.name}\nTier:   {tier} ({TIERS[tier]})")
    if tier == "T3":
        audit("action", name=a.name, tier=tier, decision="refused")
        raise SystemExit("Refused: T3 actions are never allowed.")
    if tier == "T0":
        audit("action", name=a.name, tier=tier, decision="allowed")
        print("Allowed: read-only.")
        return
    approver = input("Approver name (blank = reject): ").strip() if a.approver is None else a.approver
    typed = input('Type APPROVE to approve: ').strip() if a.approver is None else "APPROVE"
    decision = "approved" if approver and typed == "APPROVE" else "rejected"
    audit("action", name=a.name, tier=tier, decision=decision, approver=approver or "-",
          operator=getpass.getuser())
    if decision == "rejected":
        print("Rejected: nothing done.")
    elif tier == "T1":
        print(f"Approved by {approver}: the assistant may perform this low-risk action.")
    else:
        print(f"Approved by {approver} as a PROPOSAL. A human engineer executes it under change control.")


def main():
    ap = argparse.ArgumentParser(description="Capstone starter assistant")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("check"); s.add_argument("file"); s.set_defaults(fn=cmd_check)
    s = sub.add_parser("troubleshoot"); s.add_argument("--symptom", required=True, choices=["latency", "bgp"])
    s.add_argument("--evidence", required=True); s.add_argument("--send", action="store_true"); s.set_defaults(fn=cmd_troubleshoot)
    s = sub.add_parser("rca"); s.add_argument("--timeline", required=True); s.add_argument("--incident", required=True)
    s.set_defaults(fn=cmd_rca)
    s = sub.add_parser("logs"); s.add_argument("--entity", required=True, action="append", help="fictional account, host, or IP to correlate (repeatable)")
    s.set_defaults(fn=cmd_logs)
    s = sub.add_parser("action"); s.add_argument("--name", required=True); s.add_argument("--tier", required=True, choices=list(TIERS))
    s.add_argument("--approver", help="non-interactive approver name (for demos and tests)"); s.set_defaults(fn=cmd_action)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
