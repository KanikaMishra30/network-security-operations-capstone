# AI-Powered Network and Security Operations Assistant

## Overview

This capstone is an offline, fictional-data assistant for preparing network and security operations investigations. It checks and sanitizes evidence, builds prompts for troubleshooting and incident RCA, correlates selected logs, and provides a tiered human-approval gate. Generated prompts are saved locally for analyst review; the assistant does not call an AI service automatically.

The target user is a NOC Tier-2 Network Operations Analyst.

## Requirements and Setup

- Python 3.10 or later.
- The capstone assistant and its log helper use the Python standard library; no third-party package installation is required to run these commands.

From the repository root:

```bash
cd m12-capstone
python3 --version
python3 assistant.py --help
```

For the full lab pack, return to the repository root, then install the packages and run the setup check:

```bash
cd ..
python3 -m pip install -r setup/requirements.txt
bash setup/check-setup.sh
```

Those broader lab dependencies are not needed by this assistant alone.

## Folder Structure

```text
m12-capstone/
  assistant.py                 CLI entry point
  prompts/                     prompt templates, including logs.md and alerts.md
  samples/                     fictional router output and incident timeline
  out/                          generated prompts and response artifacts
  audit/                        append-only-style local JSONL activity record
  docs/                         scope statement and test record
  demo/                         response and verification examples
```

The logs command reuses `../m06-threat-analysis/correlate.py` and its data under that module. The alert triage helper is `../m05-secops/triage_helper.py`.

## Commands

Run commands from `m12-capstone/`.

### Check evidence

```bash
python3 assistant.py check samples/router-output.txt
```

Prints detected finding categories (not the matched sensitive content) and records a check event in `audit/assistant-audit.jsonl`. A finding means the evidence must be sanitized before use.

### Troubleshoot

```bash
python3 assistant.py troubleshoot --symptom bgp --evidence samples/router-output.txt
```

`--symptom` accepts `bgp` or `latency`. Supply the corresponding evidence file with `--evidence`. The assistant sanitizes and checks the evidence, fills `prompts/runbook-<symptom>.md`, saves a timestamped prompt to `out/`, and records the run in the audit log.

### RCA

```bash
python3 assistant.py rca --timeline samples/timeline.txt --incident INC-OUTAGE-1015
```

Sanitizes and checks the timeline, fills `prompts/rca.md`, and saves a timestamped prompt to `out/`.

### Logs

```bash
python3 assistant.py logs --entity r.mehta --entity 10.20.250.37 --entity 10.20.6.15
```

Accepts one or more fictional entities. The command makes sanitized temporary copies of the helper's input files, invokes the Module 6 helper without a shell, checks its output and the complete generated prompt, and saves a clean prompt to `out/`. It does not modify original logs.

### Human approval gate

```bash
python3 assistant.py action --name "inspect lab status" --tier T0
python3 assistant.py action --name "open lab ticket" --tier T1
python3 assistant.py action --name "propose firewall review" --tier T2
python3 assistant.py action --name "delete logs" --tier T3
```

T1 and T2 prompt interactively for an approver and the exact text `APPROVE` (case-sensitive). These commands record gate decisions; this capstone has no integration that carries out a real ticket or network operation.

### Alert triage helper

There is not currently an `assistant.py alerts` subcommand. To run the Module 5 helper directly, change to `../m05-secops/` and run:

```bash
python3 triage_helper.py
```

Without `--out`, it reads its default alert/context files and prints scores, clusters, and flags. These are triage hints, not verdicts. Supplying `--out` writes an enriched CSV.

## Using Prompts with Copilot

1. Run a prompt-generating command and note the timestamped filename printed under `out/`.
2. Open that prompt file in VS Code and review the sanitized evidence and instructions.
3. In GitHub Copilot Chat, attach the prompt with `#file out/<generated-filename>.txt` and submit it for analysis.
4. Review the response against the source evidence before using or exporting it.

The assistant does not call Copilot itself. The `--send` troubleshooting option is not usable until `llm_call()` is implemented; it currently raises `NotImplementedError`.

## Approval Tiers

| Tier | Behavior |
|---|---|
| T0 | Read-only request is allowed and audited. |
| T1 | Low-risk write requires a named approver and exact `APPROVE`; the gate currently records the decision but does not execute an external action. |
| T2 | Approved request is only a proposal for a human to execute under change control; it is not applied by this assistant. |
| T3 | Refused and audited. |

## Safety Limitations

- Use fictional lab data only. The project is offline and does not connect to production devices.
- Treat logs, alerts, and helper output as untrusted evidence. Sanitization and detection use patterns and are not a guarantee that every secret or prompt injection will be found. Review the evidence and generated prompt before sending it to Copilot.
- The `check` command reports matched categories; a zero-finding result is not proof that evidence is safe.
- Helper scores, flags, and clusters are not proof of malicious activity or causation.
- No production configuration changes, automatic IP blocking, alert closure, or log deletion are implemented or in scope.
- Human approval is a local gate and audit trail, not a production action executor.

## Testing

There is no automated test suite in this capstone. Run the following smoke checks from `m12-capstone/`:

```bash
python3 assistant.py --help
python3 assistant.py check samples/router-output.txt
python3 assistant.py logs --entity r.mehta --entity 10.20.250.37 --entity 10.20.6.15
```

The sample router file is expected to produce findings; generated prompts should be checked and should have no unresolved findings before use. The logs command should print the generated prompt path and add a `logs` event to the audit file. The alert helper can be smoke-tested from `../m05-secops/` with `python3 triage_helper.py` and no `--out`.

Review `docs/test-record.md` for recorded results, including the T0-T3 gate tests and injection/sanitization checks. It documents failed or unimplemented paths as well as passes.
