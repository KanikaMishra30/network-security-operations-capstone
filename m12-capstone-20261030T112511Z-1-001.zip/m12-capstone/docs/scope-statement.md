# Scope Statement

## Project Name

AI-Powered Network and Security Operations Assistant

## Target User

NOC Tier-2 Network Operations Analyst

## Operational Problem

Network and security operations analysts must review troubleshooting evidence, incident timelines, logs, and alerts from multiple sources. Manually sanitizing and correlating this evidence can make investigations inconsistent and difficult to audit. Supplying untrusted logs or alert content to an AI assistant also creates a risk that sensitive data or embedded instructions will be mishandled. The project provides an offline, read-only workflow to prepare evidence-based prompts and preserve a local audit trail, while keeping operational decisions under human control.

This describes the problem the project is designed to address; no production baseline or measured impact has been supplied.

## Scope

The assistant is a fictional-data training capstone. Its scripts work offline, do not connect to real devices, and prepare prompts for review in the approved AI tool. The assistant does not independently diagnose or remediate production systems.

### Mandatory Components

- **Troubleshooting:** Sanitize and check supplied evidence, then prepare a runbook-based prompt for network troubleshooting.
- **Root cause analysis (RCA):** Sanitize and check an incident timeline, then prepare a blameless RCA prompt.
- **Human approval:** Provide a tiered gate and audit record for requested actions. T0 is read-only; T1 requires approval for a low-risk write; T2 can produce a change proposal for a human to execute under change control; T3 is refused. The gate records decisions and does not itself connect to production systems or execute network changes.

### Extensions

- **Logs:** The read-only logs subcommand reuses the Module 6 correlation helper, uses sanitized temporary evidence copies, checks the helper output and generated prompt, and records the run. Original logs are not modified.
- **Alerts:** Alert analysis uses the Module 5 triage helper and alert prompt to prioritize review. The helper is read-only when run without its `--out` option. An integrated `assistant.py alerts` subcommand is not currently implemented; integrating and validating that extension remains in scope.

## Exclusions

- Production configuration changes or direct device access.
- Automatic IP blocking or other automated response actions.
- Alert closure or suppression by the assistant.
- Log deletion or modification of source logs.
- Automated attribution or declaring compromise solely from scores, flags, correlations, or generated analysis.

## Team Members and Contributions

The supplied project materials do not identify the capstone team members or their individual contributions. Complete this table with the team's agreed information; names and assignments are not inferred here.

| Team member | Contribution |
|---|---|
| Not provided | Not provided |

## Expected Operational Benefits

Expected qualitative benefits include more consistent evidence handling, faster access to structured investigation prompts, clearer separation of observations from hypotheses, improved traceability through local audit records, and reduced risk of acting on untrusted input without human review. These are intended benefits, not measured outcomes. No time savings or other quantitative improvement is claimed because no measurements have been provided.
