# Jailbreak Security Test Plan

**Owner:** AI Lead  
**Assessment date:** 2026-10-29  
**Status:** Offline static and sanitizer regression testing completed; end-to-end model testing not performed.

## 1. Purpose

Assess whether local assistant controls protect secrets and preserve instruction
and authorization boundaries when fictional operational content contains
adversarial instructions. The plan is limited to the training workspace and
must not be used against production systems.

## 2. Objectives

- Evaluate the local prompt-injection detector patterns against the available
  jailbreak fixtures.
- Retest the capstone evidence sanitizer for representative synthetic
  credential formats.
- Verify that check findings do not print the matched synthetic secret.
- Record expected outcomes, observed results, limitations, and follow-up work.
- Keep static detector results distinct from actual model and tool behavior.

## 3. Scope and test basis

### In scope

- The 30-case catalog in
  [Jailbreak testcase.csv](../Jailbreak%20testcase.csv).
- The seven-case original fixture in
  [jailbreaktesting1.csv](../jailbreaktesting1.csv).
- Static checks against the agent prototype injection expression and the
  capstone checker.
- Synthetic credential redaction checks in the capstone sanitizer.
- Documentation of risk, remediation, and residual limitations.

### Out of scope

- Sending prompts to a connected language model or measuring model refusal.
- Testing external services, devices, accounts, or ticketing systems.
- Executing a configuration, ticket-status, or containment action.
- Establishing the frequency or financial impact of real-world incidents.
- Proving that pattern-based sanitization detects every possible secret.

## 4. Environment and safety controls

- Use only fictional fixture content and synthetic credential values.
- Run offline; no external connection or device change is authorized.
- Do not insert real secrets, personal data, customer identifiers, or production
  records into fixtures.
- Treat all ticket, log, document, and email text as untrusted data.
- Do not interpret a detector miss as permission to act or evidence that content
  is safe.
- Do not report a model pass/fail when no model was invoked.

## 5. Method

1. Load each test input from the available CSV fixtures.
2. Compare the input with the local agent's injection-detection expression and
   the capstone checker's configured patterns.
3. Record `FLAGGED` or `NOT FLAGGED`; a match means only that a local pattern
   fired.
4. Run synthetic credential values through capstone `sanitise()` and `check()`.
5. Confirm redaction removes the synthetic value, the sanitized result has no
   residual matching credential finding, and a positive control is detected
   without returning its value.
6. Record results with clear execution scope and limitations.
7. Review findings and track remediation separately from test observations.

## 6. Expected outcomes and acceptance criteria

| Test area | Expected outcome | Acceptance criterion |
|---|---|---|
| Static injection indicators | Obvious configured patterns may be flagged. | All results identify the specific detector and do not claim model safety. |
| Credential redaction | Supported synthetic credential formats are replaced. | No synthetic credential value remains, and no residual secret finding is returned for tested formats. |
| Positive control | An unsanitized supported-format credential is detected. | Checker reports a category only; the secret value is not returned. |
| Authorization and tool action | No device or external action is run in this offline plan. | Tool actions are recorded as not attempted, not passed. |
| Model response | Requires a connected approved model and separate authorization. | Marked not tested in this assessment. |

## 7. Result interpretation

- **PASS:** The specific local sanitizer regression check met its stated
  criterion.
- **FAIL / coverage gap:** A configured static detector did not flag the
  fixture. This is a detector coverage observation, not proof of a successful
  model jailbreak.
- **STATIC CHECK ONLY:** A prompt fixture was checked for pattern matches;
  response safety and action controls were not exercised.
- **NOT TESTED:** A control requires a connected model, integration, or action
  surface unavailable in the offline lab.

## 8. Test inventory

- 30 expanded jailbreak test cases.
- 7 original jailbreak fixtures.
- 10 credential-sanitization regression checks, including one positive
  detection control.

The test repository and execution details are linked from
[test-case-repository.md](./test-case-repository.md) and
[test-execution-summary.md](./test-execution-summary.md).
