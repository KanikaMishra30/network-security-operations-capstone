# Jailbreak Test Execution Summary

**Execution date:** 2026-10-29  
**Execution mode:** Offline, local static pattern checks and synthetic
sanitizer regression tests  
**Overall conclusion:** Credential redaction is confirmed for the tested
formats. End-to-end jailbreak resistance remains unverified.

## Results at a glance

| Test set | Cases | Observed result | Interpretation |
|---|---:|---|---|
| Original detector run against expanded JTC catalog | 30 | 1 partial detector pass; 29 static detector coverage gaps | One fixture triggered both local detector patterns. Remaining cases were not flagged by either configured detector. No model or action was tested. |
| Latest static retest: original JBT fixtures | 7 | Static matches only | Agent guard flagged 1; capstone checker matched 2, one being an instruction indicator and one a credential-pattern match. |
| Latest static retest: expanded JTC catalog | 30 | Static matches only | Agent guard flagged 1; capstone checker matched 6, including broad credential-pattern matches that may be false positives. |
| Credential sanitization regression | 10 | 10 PASS | Nine synthetic redaction formats and one positive control passed locally. |

See the row-level evidence in
[Jailbreak test execution results.csv](../Jailbreak%20test%20execution%20results.csv)
and [jailbreak-retest-results.csv](../jailbreak-retest-results.csv).

## Credential retest details

The 10 checks covered:

1. Password assignment.
2. Token assignment.
3. API-key assignment.
4. Numbered CLI secret.
5. Bearer authorization.
6. Basic authorization.
7. URL credentials.
8. PEM private-key block.
9. SNMP community.
10. Positive control: an unsanitized synthetic credential was detected, and
    the checker returned only the finding category.

All ten passed for their specific synthetic inputs. This supports remediation
of the identified format-coverage issue for these formats; it is not proof
that arbitrary or unknown secret formats are detected.

## Retest correction

During retest, a case-sensitivity regression was found in the capstone checker:
case-sensitive matching failed to flag a capitalized injection phrase. The
checker was updated to use case-insensitive matching and the fixtures were
rerun. The current row-level retest reflects the restored behavior.

## Not tested

- No connected LLM was invoked; actual refusal, compliance, or instruction
  hierarchy behavior was not evaluated.
- No tool call, external service, ticket update, network connection, or device
  action was attempted.
- Static detector matches are not model pass/fail outcomes. A detector miss is
  not proof that the content is safe.
- The retest records the capstone checker's configured regex results; its
  broad credential matcher can produce matches that are not actual secrets.

## Exit assessment

- **JBR-01 credential sanitization:** Remediated and regression-tested for the
  formats listed above; residual risk remains for unrecognized formats.
- **Prompt-injection detector coverage:** Open validation/control gap. The
  phrase matchers are narrow heuristics and must not be used as the sole
  security boundary.
- **End-to-end model jailbreak:** Not tested; no conclusion of model resilience
  is supported by this run.

## Recommended next execution

After authorization and connection to an approved non-production model
environment, run a separate integration test using mocked or disabled tools.
Capture model responses, tool-call attempts, approval decisions, and audit
events for each case. Keep credentials and production data out of prompts and
fixtures. Report model and tool behavior separately from static detector
results.
