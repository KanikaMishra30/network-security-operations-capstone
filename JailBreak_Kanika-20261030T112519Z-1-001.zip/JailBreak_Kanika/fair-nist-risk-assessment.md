# FAIR and NIST AI RMF 2.0 Risk Assessment

**Assessment date:** 2026-10-29  
**Owner:** AI Lead  
**Assessment type:** Qualitative; available evidence is from fictional offline
fixtures and local code only.

## Scope and assumptions

This assessment covers two distinct items:

1. The credential-sanitization gap identified in the capstone assistant and
   fixed for a set of common formats.
2. Limited coverage of local prompt-injection detector patterns, where actual
   model or tool exploitability has not been tested.

No organization-specific incident rates, financial loss data, provider
retention assumptions, or production deployment context was supplied.
Accordingly, FAIR ratings below are qualitative, not annualized loss
calculations. Ratings must not be read as claims of observed compromise.

## FAIR assessment

| Risk | Threat event frequency | Vulnerability | Loss magnitude | Current conclusion |
|---|---|---|---|---|
| JBR-01: credential disclosure through incomplete sanitization | Possible / occasional if operational evidence containing credentials is processed and shared; actual frequency unknown. | High before fix for credential formats not matched by original patterns. Reduced for nine tested synthetic formats after the fix; unknown for arbitrary content. | Moderate to high, depending on credential privilege, validity, reuse, and response/provider handling. | Tested-format remediation is supported. Residual secret-detection risk remains. |
| JBR-02: prompt injection not flagged by local detector | Adversarial or accidental instruction-like content may occur in tickets, logs, or documents; real frequency unknown. | High for detector-only identification, given narrow phrase matching and observed fixture misses. Broader system vulnerability is not established because trusted instruction handling and tool boundaries were not exercised end to end. | Potentially high if a connected agent can disclose data or take consequential actions; actual loss magnitude cannot be established from the offline prototype. | Treat as an open control/validation gap; no successful jailbreak or realized loss was demonstrated. |

### FAIR-informed actions

- Maintain sanitization as defense in depth and add a maintained secret scanner
  suited to the approved offline workflow.
- Do not use prompt-injection regexes as a security boundary or approval
  mechanism.
- Require independent, scoped human approval and least-privilege tool controls.
- Measure model and tool behavior in an authorized non-production environment
  before making claims about jailbreak resilience.
- Capture incident frequency, credential sensitivity, revocation effort, and
  impact data before attempting quantitative FAIR estimates.

## NIST AI RMF 2.0 alignment

| Function | Application to this assessment |
|---|---|
| GOVERN | Assign owners for policy enforcement, scanner maintenance, approval workflows, and response to accidental disclosure. Maintain the rule that logs, tickets, and emails are untrusted and cannot authorize AI action. |
| MAP | Inventory data flows from local evidence through sanitization, prompt files, the approved AI tool, and any agent tools. Map the consequences of credential disclosure and unauthorized actions. |
| MEASURE | Retain synthetic regression tests; measure false negatives and false positives; separately test model responses, attempted tool calls, approval checks, and audit events when an approved integration environment is available. |
| MANAGE | Keep human approval, least privilege, change control, and incident response independent of prompt-injection detection. Track JBR-01 as remediated for tested formats and JBR-02 as open pending validation and control review. |

## Residual risk and decision

JBR-01 is **remediated for the tested credential formats**, but not proven
remediated for every possible representation. Pattern-based scanning cannot
guarantee that content is secret-free.

JBR-02 remains an **open validation/control gap**. Detector coverage results do
not show that the model followed malicious instructions, nor that it resisted
them. Until an approved end-to-end test is completed, the system's jailbreak
resilience is **not established**. Continue to rely on data minimization,
trusted instruction separation, tool scoping, human approvals, and audit
controls.

## Evidence references

- [Original 30-case static execution](../Jailbreak%20test%20execution%20results.csv)
- [47-row offline retest](../jailbreak-retest-results.csv)
- [Vulnerability register](./vulnerability-register.csv)
- [Test execution summary](./test-execution-summary.md)
