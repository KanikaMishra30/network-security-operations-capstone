# Jailbreak Test Case Repository

**Repository owner:** AI Lead  
**Version date:** 2026-10-29  
**Canonical expanded case file:** [Jailbreak testcase.csv](../Jailbreak%20testcase.csv)

The canonical CSV is the source of truth for 30 expanded test cases. It
contains scenario, adversarial test input, expected outcome, measurable pass
criteria, category, and severity. Do not edit a second copy of the same cases;
update the canonical CSV and preserve the stable `JTC-###` identifiers.

## Inventory

| Category | Case IDs | Count |
|---|---|---:|
| Instruction override and secret exfiltration | JTC-001 | 1 |
| Authorization, impersonation, and tool scope | JTC-002, JTC-010, JTC-018, JTC-019 | 4 |
| Incident integrity, concealment, and evidence | JTC-003, JTC-005, JTC-007, JTC-024 | 4 |
| Prompt injection and trust-boundary handling | JTC-004, JTC-008, JTC-011, JTC-012, JTC-013, JTC-014, JTC-015, JTC-016, JTC-017, JTC-025 | 10 |
| Secret and privacy protection | JTC-006, JTC-021, JTC-022, JTC-023, JTC-027, JTC-029 | 6 |
| External communication and test isolation | JTC-020, JTC-028 | 2 |
| Safe refusal and recovery | JTC-009, JTC-026, JTC-030 | 3 |
| **Total** | **JTC-001–JTC-030** | **30** |

## Original fixtures

The original seven cases, identified as `JBT-001` through `JBT-007`, remain in
[jailbreaktesting1.csv](../jailbreaktesting1.csv). The single-case seed fixture
is [Jailbreak.csv](../Jailbreak.csv). These are useful supplemental inputs;
they are not substitutes for the expanded canonical catalog.

## Severity distribution

| Severity | Count |
|---|---:|
| Critical | 9 |
| High | 20 |
| Medium | 1 |

Severity is a prioritization label for the scenario, not an observed loss or
proof that the scenario is exploitable in a model.

## Case management conventions

- Keep test data fictional and safe; use placeholders instead of secrets.
- Preserve stable identifiers when updating wording or expected outcomes.
- Add a new identifier for a materially different threat scenario.
- Record the exact test method and observed result in an execution report.
- Separate static pattern results from model-response, tool-call, and workflow
  results.
- Do not label a case passed unless the applicable pass criteria were actually
  exercised.

## Related artifacts

- [Original detector execution results](../Jailbreak%20test%20execution%20results.csv)
- [Latest offline retest results](../jailbreak-retest-results.csv)
- [Test execution summary](./test-execution-summary.md)
