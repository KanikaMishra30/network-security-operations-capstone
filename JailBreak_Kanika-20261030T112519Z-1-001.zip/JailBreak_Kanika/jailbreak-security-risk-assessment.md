# Jailbreak Security Risk Assessment

**Assessment date:** 2026-10-29  
**Prepared by:** AI Lead  
**Scope:** Local jailbreak test cases and execution results, the capstone assistant's prompt sanitization/checking path, the agent prototype's injection guard, and the approved AI usage policy.

## Executive summary

One high-risk input-sanitization weakness was substantiated in the capstone
assistant: the original sanitizer and checker recognized only a narrow set of
credential formats. Common assignment-style credentials could pass through the
sanitization step into a prompt intended for the approved AI tool. This could
violate the policy against sharing secrets and cause credential exposure.

**Status: Remediated in the local capstone code.** The sanitizer now redacts
common password/token/key assignments, authorization credentials, URL
credentials, SNMP communities, and private-key blocks. The checker reports
finding categories without returning matched values. This is a focused
pattern-based mitigation, not proof that arbitrary secrets can always be
detected.

No end-to-end model jailbreak or tool-action bypass was established. The lab
does not connect to an LLM, and the existing jailbreak execution results are
static detector checks rather than model-response tests.

## Finding

### JBR-01 — Incomplete credential sanitization could expose secrets

| Attribute | Assessment |
|---|---|
| Severity before remediation | High |
| Confidence | 9/10 |
| Affected component | `m12-capstone/assistant.py` sanitization and prompt preparation |
| Policy relevance | The approved policy prohibits sharing secrets with AI tools. |
| Status | Remediated; focused local tests passed. |

**Evidence and impact:** Before the change, sanitizer/checker patterns matched
only limited secret formats. Other common formats, such as key-value
credential assignments, bearer authorization values, URL credentials, and PEM
private-key blocks, could escape those patterns. Troubleshooting and RCA
sanitize and check evidence before creating prompt files for manual handoff to
the approved AI tool. A missed credential could therefore be included in that
prompt.

**Code fix:** Updated [assistant.py](../m12-capstone/assistant.py) to:

- Redact common password, secret, token, API/access/client/private-key
  assignments, including numbered CLI secret forms.
- Redact bearer/basic authorization values, URL credentials, SNMP communities,
  and complete PEM private-key blocks.
- Return finding categories only, avoiding the previous behavior of printing a
  prefix of matched content that could itself contain sensitive data.
- Keep the existing fail-closed prompt preparation behavior when checks still
  find sensitive content after sanitization.

### FAIR assessment

Qualitative assessment, using the FAIR concepts of threat-event frequency,
vulnerability, and loss magnitude. No organization-specific loss data was
provided, so no numerical annualized loss estimate is asserted.

| FAIR factor | Assessment | Rationale |
|---|---|---|
| Threat-event frequency | Possible / occasional | Operational logs and timelines can contain credentials, and users may use the documented prompt handoff. Actual frequency is unknown. |
| Vulnerability before fix | High | The original patterns were narrow and did not cover common credential formats. |
| Loss magnitude | Moderate to high | Exposure could require credential revocation and incident response; impact depends on credential privilege, validity, reuse, and provider handling. |
| Residual risk after fix | Reduced, but not eliminated | Broader patterns and synthetic tests reduce known-format misses. Regex checks cannot prove arbitrary content is secret-free. |

### NIST AI RMF 2.0 alignment

| Function | Risk and recommended treatment |
|---|---|
| GOVERN | Keep the no-secret-sharing policy enforceable in workflows and assign an owner for secret-scanning rules and exceptions. |
| MAP | Document the flow from local evidence through sanitization to prompt files and approved AI tools; identify sensitive-data impact. |
| MEASURE | Test scanning against representative credential formats and benign near-matches; track misses and false positives. |
| MANAGE | Fail closed on findings, restrict prompt sharing to approved tools, and apply the incident process—including revocation—if disclosure occurs. |

## Related test observation

The existing [Jailbreak test execution results.csv](./Jailbreak%20test%20execution%20results.csv)
records that the two local prompt-injection detectors flagged only JTC-001 of
30 static test inputs; 29 inputs were not flagged. This demonstrates limited
coverage of those specific detector expressions, **not** a successful model
jailbreak. The results explicitly state that assistant behavior and tool
actions were not tested.

The agent prototype's injection check is a narrow phrase-matching heuristic.
It should be treated as a signal for review, not as a security boundary or
proof that content is safe. The reviewed implementation also has separate
tool-tier and approval controls. Given the offline-only prototype and absence
of an LLM call, a prompt-injection-to-tool-action bypass was not substantiated
in this assessment.

## Mitigation and validation

1. **Applied:** Broaden local redaction and detection patterns in the capstone
   assistant; suppress matched content in findings.
2. **Validated:** `assistant.py` compiles. Synthetic tests passed for password
   assignments, tokens, API keys, numbered CLI secrets, bearer/basic
   authorization, URL credentials, private-key blocks, and SNMP communities.
   The checker also reports a category without returning the synthetic value.
   A subsequent retest caught a case-sensitivity regression in the checker;
   case-insensitive matching was restored and revalidated.
3. **Recommended next:** Adopt a maintained secret-scanning control for
   pre-prompt checks, retaining local/offline operation where required; do not
   treat regex sanitization as a guarantee.
4. **Recommended next:** Add automated regression tests for sanitization and
   detector behavior. Keep untrusted ticket/log/document text data-only, and
   enforce authorization and least-privilege tool boundaries independently of
   prompt-injection detection.
5. **Operational response:** If a real secret is suspected to have been shared,
   stop the activity, notify the Security Lead, and revoke or rotate the secret
   through the approved incident process.

## Limitations

- Tests used synthetic values only; no real secrets or external services were
  used.
- The new tests validate local sanitization functions, not a connected model's
  resistance to adversarial prompts.
- Pattern-based scanners can miss unknown formats or values embedded in
  unusual content. The approved usage policy and human review remain necessary.

## Retest update

The latest offline retest is recorded in
[jailbreak-retest-results.csv](./jailbreak-retest-results.csv). All 10
credential-sanitization regression checks passed, including a positive control
confirming that an unsanitized synthetic credential is detected without
returning its value. This confirms remediation for the tested formats, not
for every possible secret representation.

The retest also rechecked 37 prompt fixtures. The agent's narrow injection
pattern flagged 2; the capstone checker produced 8 matches, including broad
credential-pattern matches that may be false positives. These static matches
do not establish safe model behavior. No connected LLM, end-to-end response,
or tool action was tested, so broader jailbreak resistance remains unverified.
